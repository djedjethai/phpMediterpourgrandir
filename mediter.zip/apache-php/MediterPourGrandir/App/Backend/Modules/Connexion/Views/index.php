<section class="section-book">
     	<div class="rowgrid">
             	<div class="booknopic">
                    	<div class="booknopic__form">
                        	<form action="" class="form" method="post">
						
					<div class="u-center-text u-margin-top-medium u-margin-bottom-medium">
                                		<h2 class="heading-secondary">
                                    			Connexion
                                		</h2>
                            		</div>

					<form action="" method="post">
						<div class="form__group">
						<label class="form__label">Pseudo</label>
					  	<input type="text" name="login" class="form__input"/><br />
						</div>

						<div class="form__group">
					  	<label class=form__label>Mot de passe</label>
					  	<input type="password" name="password" class="form__input"/><br /><br />
						</div>

						<input class="btn-choice-btn u-margin-bottom-small" type="submit" value=" Connexion" />    	
				</form>
		    	</div>
		</div>
	</div>
</section>




