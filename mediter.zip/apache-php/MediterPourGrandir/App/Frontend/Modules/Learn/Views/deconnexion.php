<main>
	<section class="section-report">
     		<div class="rowgrid">
				<div class="report">
					<div class="report__box">
					<p class="paragraph">Vous êtes deconnecté(e), tous les cookies ont été supprimés.</p>
					</div>
				</div>
		</div>
	</section>
</main>


