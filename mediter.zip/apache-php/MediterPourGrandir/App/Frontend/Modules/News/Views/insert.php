<section class="section-book">
     	<div class="rowgrid">
             	<div class="booknopic">
                    	<div class="booknopic__form">
                        	<form action="" class="form" method="post">
					
					<div class="u-margin-bottom-medium">
               	<a href="/news/index-1.php" class="btn-text">&Larr;Retour aux news</a>
					</div>

					<div class="u-center-text u-margin-top-medium u-margin-bottom-medium">
                                		<h2 class="heading-secondary">
                                    			Ajoutez une news
                                		</h2>
                            		</div>
		  	    		
			       		<?= $form ?>

					<input class="btn-choice-btn u-margin-bottom-small" type="submit" value=" Envoyer" />    	
				</form>
		    	</div>
		</div>
	</div>
</section>


