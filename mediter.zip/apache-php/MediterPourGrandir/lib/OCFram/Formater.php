<?php

namespace OCFram;


interface Formater {
	public function format($text);
}